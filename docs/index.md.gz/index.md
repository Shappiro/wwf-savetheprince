Save the Prince!
==========================

Save the Prince! è un progetto della community [WWF YOUng Italia][0] volto a promuovere e coordinare gli sforzi dei volontari impegnati nei salvataggi degli anfibi dagli investimenti stradali: durante le migrazioni primaverili verso i luoghi di riproduzione, tale classe di sensibilissimi vertebrati (i primi a subire le pressioni del cambiamento climatico, delle malattie e della frammentazione degli habitat secondo la [IUCN][1]) subisce pesantissime perdite a causa degli investimenti durante l'attraversamento di arterie stradali. Spostandosi spesso in notturna, l'unico modo di ridurre tale impatto è rappresentato spesso dall'azione dei volontari, che con metodi adeguati spostano gli esemplari da una carreggiata all'altra della strada, allo stesso tempo memorizzando i dati del numero individui raccolti. 

L'azione è supportata da numerose associazioni, tra le quali non possiamo fare a meno di nominare [WWF Italia][2] e [SOS Anfibi][3].

![logo-wwf-young]({{ site.url }}/wwf_prince/assets/img/young.png "WWF YOUng") ![logo-wwf-italia]({{ site.url }}/wwf_prince/assets/img/WWF.png "WWF Italia")

...Per approfondire, c'è pure un [Little Talk][4]!
# Tecnologie
Il sito è costruito con [Python][4] usando il framework di sviluppo web [Django Web Framework][5] (usando come base un "Fantastic Project Starter", [Edge][6]) e il database [PostgreSQL][7] in congiunzione con la sua estensione spaziale [PostGIS][8].

Il progetto è composto dalle seguenti, semplici, applicazioni:

* profiles (gestione delle anagrafiche dei volontari e delle associazioni) 
* observations (memorizzazione delle osservazioni per i siti di salvataggio)
* maps (visualizzazione su base cartografico/statistica dei dati)

### Quick start

Per lanciare velocemente il sito in locale, dopo aver copiato il *repository* è sufficiente installare
Python 3 e attivare l'ambiente virtuale all'interno del quale il progetto è impacchettato:

    python3 -m venv wwf_prince
    ./wwf_prince/bin/activate

Si installano quindi tutte le dipendenze:

    pip install -r requirements.txt

Ed infine, si effettuano le migrazioni sul proprio database:

    python manage.py migrate

Il sito è preimpostato per funzionare su un database PostgreSQL (configurazioni in *wwf_prince/settings*), ma in locale, si può tranquillamente lavorare su un *backend* SQLite, applicando nel file di cui sopra:

	DATABASES = {
    	'default': env.db(),
	}

[0]: https://www.wwf.it/tu_puoi/wwf_young/
[1]: https://en.wikipedia.org/wiki/List_of_endangered_amphibians
[2]: https://www.wwf.it
[3]: https://www.sosanfibi.it
[4]: https://www.facebook.com/WWFYOUng/videos/1585922534861522/
[5]: https://www.python.org/
[6]: https://www.djangoproject.com/
[7]: https://github.com/arocks/edge
[8]: https://www.postgresql.org
[9]: https://postgis.net

# Dedicato a...
Il sito è dedicato ad Enrico Romanazzi: che la sua memoria sia viva per sempre nell'animo di ogni rospista! 
